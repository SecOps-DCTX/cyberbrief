# Assets

| File | Notes |
|---|---|
| `dc-seal-placeholder.svg` | **Placeholder.** Stand-in for the official Denton County seal. Replace before any production use. |
| `dc-wordmark.svg` | Wordmark lockup combining a simplified seal mark with the "Denton County" name. Also a placeholder — needs Communications approval. |

**Asks for the user:**
- Drop the official high-resolution Denton County seal here (PNG + SVG if available).
- Provide the official wordmark / lockup if one exists.
- Provide a small library of approved Denton County photography (courthouse, parks, residents at events) — currently none included.

Icons are pulled from [Lucide](https://lucide.dev) at runtime via CDN; no icon files live in this folder.
